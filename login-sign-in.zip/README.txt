A Pen created at CodePen.io. You can find this one at http://codepen.io/GeBuOr/pen/mJJmgx.

 A concept of login and sign-in modal